const insuranceCard = [
  {
    title: "qwe",
    mainText: "ew",
    image: "../src/img/insurance/insurance-card-01.jpg",
    rubric: "Автострахование",
  },
];
export default insuranceCard;
